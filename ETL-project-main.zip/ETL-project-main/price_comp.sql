DROP TABLE price_comp;
CREATE TABLE price_table(
date VARCHAR,
bitcoin_price INT,
gold_price INT
);