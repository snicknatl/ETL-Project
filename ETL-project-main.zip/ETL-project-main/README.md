# ETL-project
With increasing hype around cryptocurrencies, we decided to dig into the prices of bitcoin and gold. We understood that these prices would contrast but finding a data set proved more difficult than expected. On Kaggle, we discovered that many of the formatted, available datasets could make our data transformation more difficult or, in some cases, impossible. 

The main use for this dataset is that it provides datapoints which can be used for exploratory data analysis involving bitcoin and gold whereas the other dashboards utilizing bitcoin data do not directly relate bitcoin and gold.
